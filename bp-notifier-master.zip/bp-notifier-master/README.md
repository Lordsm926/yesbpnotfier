A notifier for [brickplanet.com](https://www.brickplanet.com/).

![](https://i.imgur.com/6f9APKt.png)

### WARNING
Brick Planet is now enforcing a mandatory 30 second delay, spamming requests faster than every 30 seconds could
result in you being banned. This repo has been updated to comply with that.

## Instructions

1. Install latest node.js (https://nodejs.org/en/).

2. Open your shell (CMD prompt, terminal, etc), and
while inside the project directory, continue to step #3.

3. Run `npm i` to install the project dependencies.

4. Rename .env.backup to .env and replace the variables with your webhook information.

Example:
```
HOOK_USER_ID=webhook_userId
HOOK_TOKEN=webhook_token
```

5. Run `node bot.js`, and the bot will post to your webhook with whatever new items come out.